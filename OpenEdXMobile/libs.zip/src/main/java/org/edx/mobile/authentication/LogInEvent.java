package org.edx.mobile.authentication;

public class LogInEvent {
}
